# Trazal — Estudio de marca

Tres propuestas originales: Linde, Enlace y Estrato. Cada carpeta incluye logos SVG y PNG, doce iconos, cartel, tokens CSS/JSON/Dart y fuentes con sus licencias.

Las tres direcciones son exploratorias; no se ha aprobado una identidad final ni comprobado el registro de marca.
