# Trazal — Estudio de marca

Tres propuestas originales: Linde, Enlace y Estrato. Cada carpeta incluye logos SVG y PNG, doce iconos, cartel, tokens CSS/JSON/Dart y fuentes con sus licencias.

Linde (amarillo) es la identidad elegida para Trazal. Enlace y Estrato se conservan como propuestas de exploración. No se ha comprobado el registro de marca.
